module Bourbon
  VERSION = "3.2.0.beta.2"
end
