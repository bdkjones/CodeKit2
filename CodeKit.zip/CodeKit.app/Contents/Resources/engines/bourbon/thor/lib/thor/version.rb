class Thor
  VERSION = "0.16.0"
end
