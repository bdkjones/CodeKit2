#
# This file replaces the entire "lib" folder created in a standard Bourbon installation within a project
# CodeKit passes this file to the Sass command line executable with the -r flag so that mixins that use
# the "compact()" function will operate correctly.
#

module Bourbon
end

module Bourbon::SassExtensions
end

module Bourbon::SassExtensions::Functions
end


# Compact function pulled from compass
module Bourbon::SassExtensions::Functions::Compact

  def compact(*args)
    sep = :comma
    if args.size == 1 && args.first.is_a?(Sass::Script::List)
      list = args.first
      args = list.value
      sep = list.separator
    end
    Sass::Script::List.new(args.reject{|a| !a.to_bool}, sep)
  end

end


module Sass::Script::Functions
  include Bourbon::SassExtensions::Functions::Compact
end

# Weird that this has to be re-included to pick up sub-modules. Ruby bug?
class Sass::Script::Functions::EvaluationContext
  include Sass::Script::Functions
end

